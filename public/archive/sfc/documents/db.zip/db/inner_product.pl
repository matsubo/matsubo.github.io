#!/usr/bin/env perl

#
# calculate correlation values between a keyword and a set of media data
# by the inner product function
#
# written by Taizo Zushi (tz@sfc.keio.ac.jp) on 2001.6.21
#

format STDOUT =
[@##]  @<<<<<<<<<<<<< @#######
$rank, $target, $cor
.

sub by_number {
   $a <=> $b;
}


if($#ARGV != 2){
    print STDERR "Usage: $0 [keyword] [keyword_file] [target_data]\n";
    exit;
}

open(KW, "$ARGV[1]") or die("ERROR: can't open $ARGV[1]\n");
open(TD, "$ARGV[2]") or die("ERROR: can't open $ARGV[2]\n");

undef %kw;
$flag = 0;
while(<KW>){
    chop($_);
    undef @keywd;
    undef $keyword;
    @keywd = split(/\s+/, $_);
    $keyword = shift(@keywd);
    if($keyword eq $ARGV[0]){
#	print @keywd;
	@kw_vector = @keywd;
	$flag = 1;
    }
}    
if($flag == 0){
    print STDERR "ERROR: the keyword \"$ARGV[0]\" is NOT defined.\n";
    exit;
}

undef %td;
while(<TD>){
    chop($_);
    undef @target;
    undef $target_name;
    @target = split(/ /, $_);
    $target_name = shift(@target);
    $cor = 0;
    for($i = 0; $i <= $#kw_vector; $i++){
#	print "$target_name: $kw_vector[$i] $target[$i]\n"
	$multi = $kw_vector[$i] * $target[$i];
#	print "$target_name: $kw_vector[$i] $target[$i] $multi\n";
	$cor += $multi;
    }
#    print "$target_name: $cor\n";
    $result = "$cor;$target_name";
    push(@result, $result);
#    print "$result\n";
}

@result = sort by_number @result;
#print "@result ";

#print "rank   title           correlation\n";
#print "----------------------------------\n";

for($i = $#result, $rank = 1; $i >= 0; $i--, $rank++){
    ($cor,$target) = split(/;/, $result[$i]);
    print "[$rank] $target: $cor\n";
#    write;
}

close(KW);
close(TD);
