#! /bin/sh
while true
do
rm test-00000.rgb
vidtomem -f test
rm tmptmp.jpg
imgcopy test-00000.rgb tmptmp.jpg
cp -f tmptmp.jpg tmp.jpg
echo "ok"

done

