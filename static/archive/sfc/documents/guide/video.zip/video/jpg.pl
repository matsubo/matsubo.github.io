#!/usr/local/bin/perl 
#  
# server push program  
# 1998 Yuichiro Nakamura  

use strict 'subs';  
$image    = 'tmp.jpg'; # image $B$N$"$j$+(B  
$interval = '10';    # wait seconds  
$boundary = 'BOUNDARY';  #  $B2hA|$N6-3&(B(MIME multipart)  
&main();  
sub main {  
    $| = 1;  
    print "HTTP/1.0 200 OK\n";  
    print "Content-type: multipart/x-mixed-replace;boundary=$boundary\n\n";  
    while (1) {  
	print "--$boundary\n";  
	if ( open( IMG , "< $image" ) ) {  
	    print "Content-type: image/jpeg\n";  # file $B$,(B jpeg $B$N>l9g(B  
	    print "Content-length: ",(stat($image))[7],"\n\n";  # file size $B$r<hF@(B  
	    while ( <IMG> ) {  
		print;  
	    }  
	    print "\n";  
	}  
	else {  
	    die "Can't open $image";  
	}  
	close(IMG);  
	sleep($interval);  
    }  
}
