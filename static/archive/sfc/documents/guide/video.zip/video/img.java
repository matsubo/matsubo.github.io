/*  
 * SimpleClientPull  
 * 1998 Yuichiro Nakamura  
 */  

import java.awt.*;  
import java.applet.Applet;  
import java.util.Date;
public class img extends Applet {  
    Image img;    // image $B$rJ]B8(B  
    Font f= new Font("Serif",Font.BOLD,20);

    int flag = 1;   // applet $B$NF0:n$r4F;k(B  
    int interval = 5000; // wait [ms]  
    String text;
    public void start() {  
	flag = 1;  
    }  
    
    public void stop() {  
	flag = 0;  
    }  
    
    public void paint ( Graphics g ) {  
	img = getImage( getDocumentBase(),"tmp.jpg");  
	MediaTracker mt = new MediaTracker(this);  
	img = getImage( getDocumentBase(),"tmp.jpg");  
	mt.addImage(img,0);  
	try {  
	    showStatus("loading image");  
	    mt.waitForAll();  
	}  
	catch (InterruptedException e){  
	    System.err.println("ERROR: "+e);  
	}  
	g.drawImage( img,0,0,this);  
	g.setFont(f);
	g.setColor(Color.blue);
	Date d= new Date();
	g.drawString(d.toString(),150,100);
	img.flush();  	
	showStatus("Client Pull interval "+interval+"[ms]");  
	if ( flag == 1 ) {  
	    repaint(interval);  
	}  
    }      
    public void update(Graphics g) {  
	paint(g);  
    }  
}
