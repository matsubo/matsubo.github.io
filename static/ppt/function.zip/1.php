<html>
<h1>Say something</h1>
<?php
 $message =  �gHELLOOOO�h;
 print $message;

?>
</html>
