<?php
// ���p
print date('Y-m-d');
print "<br>\n";
print plus(1,3);

// ���
function plus($first, $secound){
	return $first + $secound;
}
?>