<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=Shift_JIS">
<title>Form Test</title>
</head>

<body>

Genius 

<?php
	print htmlspecialchars($_POST['name']);
?>

</form>
</body>
</html>
