/*
 * Created on 2005/07/01
 *
 * $Id: StateChangedListener.java,v 1.1 2005/07/01 13:44:03 matsu Exp $
 * 
 */

/**
 * @author matsu
 * 
 */
public interface StateChangedListener {
    public void stateChange(int stage);

}
